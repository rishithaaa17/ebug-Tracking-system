# eBug-Tracker
This bug tracking system has 3 modules: Administrator, Staff &amp; Customer. The Administrator can enter staff/project details, view/assign bugs &amp; send messages. Staff can view assigned bugs &amp; provide solutions. Customers can register, send bug details &amp; view bug status.
