package com.springBoot.eBugTracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class eBugTrackerApplication {

    public static void main(String[] args) {
        SpringApplication.run(eBugTrackerApplication.class, args);
    }

}
