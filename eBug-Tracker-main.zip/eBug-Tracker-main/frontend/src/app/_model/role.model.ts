export interface Role {
    roleName: String,
    roleDescription: String
}
